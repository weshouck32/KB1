import { Client } from 'ldapjs';

export default function (kibana) {
  return new kibana.Plugin({
    id: 'ldap-plugin',
    require: ['elasticsearch'],
    config(Joi) {
      return Joi.object({
        ldapUrl: Joi.string().default('ldaps://ldap.example.com'),
        bindDN: Joi.string().default('cn=admin,dc=example,dc=com'),
        bindCredentials: Joi.string().default('adminPassword'),
        userOU: Joi.string().default('ou=users,dc=example,dc=com'),
        // Add any other plugin-specific configuration options here
      }).default();
    },
    init(server) {
      const config = server.config();
      const logger = server.log;

      const ldapClient = new Client({
        url: config.get('ldap-plugin.ldapUrl'),
        tlsOptions: {
          rejectUnauthorized: true, // Modify this as needed for your LDAPS setup
        },
        bindDN: config.get('ldap-plugin.bindDN'),
        bindCredentials: config.get('ldap-plugin.bindCredentials'),
      });

      const userOU = config.get('ldap-plugin.userOU');  // Get the user OU from config

      // Register your authentication provider
      server.plugins.security.registerAuthenticator({
        type: 'ldap-plugin',
        async authenticate(request) {
          const { username, password } = request;
          const dn = `uid=${username},${userOU}`;  // Construct the user DN using the configured OU

          try {
            await ldapClient.bind(dn, password);

            // LDAP authentication successful
            const existingUser = await server.plugins.security.getUser(username);

            if (existingUser) {
              // User profile already exists, update roles or attributes if needed
            } else {
              // User profile doesn't exist, create a new one with initial roles and attributes
              await server.plugins.security.createUser(username, {
                roles: ['superuser'],
                full_name: username, // Set other attributes here
              });
            }

            // Check if the user's password needs to be updated
            const ldapUser = await ldapClient.search(dn);
            if (ldapUser[0].passwordLastChanged !== existingUser.passwordLastChanged) {
              await server.plugins.security.changePassword(username, ldapUser[0].passwordLastChanged);
            }

            // Return the user profile
            const user = { username, roles: ['superuser'] };
            return { user };
          } catch (error) {
            logger.error('LDAP authentication error:', error);
            return null;
          }
        },
      });

      // Listen to Kibana server's 'preResponse' event to handle unauthorized access
      server.ext('onPreResponse', (request, h) => {
        const { response } = request;
        if (response.isBoom && response.output.statusCode === 401) {
          // Redirect to a custom login page or return a JSON response indicating unauthorized access
          return h.redirect('/custom-login-page');
        }
        return h.continue;
      });

      server.plugins.elasticsearch.status.on('green', () => {
        logger(['info', 'plugin'], 'LDAP Plugin initialized');
      });
    },
  });
}

