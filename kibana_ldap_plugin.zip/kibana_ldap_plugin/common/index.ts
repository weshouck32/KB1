export const PLUGIN_ID = 'kibanaLdapPlugin';
export const PLUGIN_NAME = 'kibana-ldap-plugin';
